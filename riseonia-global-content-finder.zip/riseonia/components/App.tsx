"use client";
import { useState } from "react";
import { demoAccounts, demoPosts } from "@/lib/demo";

const TABS = [
  { id: "dash", label: "Dashboard", icon: "◧" },
  { id: "discover", label: "Otomatik Hesap Keşfi", icon: "⌕" },
  { id: "accounts", label: "Keşfedilen Hesaplar", icon: "☰" },
  { id: "pool", label: "İçerik Havuzu", icon: "▦" },
  { id: "tr", label: "Türkçe Çeviriler", icon: "TR" },
  { id: "adapt", label: "RISEONIA Metin Uyarlama", icon: "✎" },
  { id: "fav", label: "Favoriler", icon: "★" },
  { id: "settings", label: "Ayarlar", icon: "⚙" },
] as const;
type TabId = (typeof TABS)[number]["id"];

const Demo = () => (
  <span className="rounded bg-white px-2 py-0.5 text-[10px] font-bold tracking-wide text-black">DEMO VERİ</span>
);
const Card = ({ children }: { children: React.ReactNode }) => (
  <div className="rounded-2xl border border-neutral-800 bg-neutral-900 p-4">{children}</div>
);
const fmt = (n: number) => n.toLocaleString("tr-TR");

export default function App() {
  const [tab, setTab] = useState<TabId>("dash");
  const [favs, setFavs] = useState<string[]>([]);
  const [text, setText] = useState("");
  const [minF, setMinF] = useState(50000);
  const toggle = (id: string) => setFavs((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
  const handleOf = (id: string) => demoAccounts.find((a) => a.id === id)?.handle ?? "";

  const PostCard = ({ id }: { id: string }) => {
    const p = demoPosts.find((x) => x.id === id)!;
    return (
      <Card>
        <div className="mb-2 flex items-center justify-between">
          <span className="text-sm text-neutral-400">{handleOf(p.accountId)} · {p.lang}</span>
          <Demo />
        </div>
        <p className="text-sm italic text-neutral-300">{p.original}</p>
        <p className="mt-2 text-base font-medium">{p.turkish}</p>
        <button onClick={() => toggle(p.id)}
          className={`mt-3 rounded-lg border px-3 py-2 text-sm ${favs.includes(p.id) ? "border-white bg-white text-black" : "border-neutral-700 text-white"}`}>
          {favs.includes(p.id) ? "★ Favoride" : "☆ Favorilere ekle"}
        </button>
      </Card>
    );
  };

  const view = () => {
    switch (tab) {
      case "dash":
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              {[["Gerçek hesap", "0"], ["Gerçek gönderi", "0"], ["Demo hesap", String(demoAccounts.length)], ["Favoriler", String(favs.length)]].map(([k, v]) => (
                <Card key={k}><div className="text-3xl font-bold">{v}</div><div className="text-xs text-neutral-400">{k}</div></Card>
              ))}
            </div>
            <Card>
              <div className="font-semibold">Bağlantı durumu</div>
              {["Brave Search", "Claude API", "Supabase"].map((s) => (
                <div key={s} className="mt-2 flex justify-between text-sm"><span>{s}</span><span className="text-neutral-400">Bağlı değil</span></div>
              ))}
            </Card>
            <Card><p className="text-sm text-neutral-400">Şu an gerçek veri yoktur. Gösterilen tüm hesap ve içerikler arayüzü test etmek için hazırlanmış DEMO verilerdir.</p></Card>
          </div>
        );
      case "discover":
        return (
          <div className="space-y-3">
            <Card>
              <label className="text-sm text-neutral-400">Minimum takipçi sayısı</label>
              <input type="number" value={minF} onChange={(e) => setMinF(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-neutral-700 bg-black p-3 text-white" />
              <div className="mt-3 text-sm text-neutral-400">Konular</div>
              <div className="mt-1 flex flex-wrap gap-2">
                {["Motivasyon", "Disiplin", "Başarı", "Kişisel gelişim", "Özgüven", "Felsefe"].map((t) => (
                  <span key={t} className="rounded-full border border-neutral-700 px-3 py-1 text-xs">{t}</span>
                ))}
              </div>
              <div className="mt-3 text-sm text-neutral-400">Diller: tüm diller</div>
              <button disabled className="mt-4 w-full rounded-xl bg-neutral-800 p-3 font-semibold text-neutral-500">Keşfi başlat (Brave API bağlı değil)</button>
            </Card>
          </div>
        );
      case "accounts":
        return (
          <div className="space-y-3">
            {demoAccounts.map((a) => (
              <Card key={a.id}>
                <div className="flex items-center justify-between"><span className="font-semibold">{a.handle}</span><Demo /></div>
                <div className="mt-1 text-sm text-neutral-400">{a.country} · {a.lang} · {a.topic}</div>
                <div className="mt-2 text-sm">{fmt(a.followers)} takipçi {a.followers >= minF ? "" : "(eşik altı)"}</div>
                <div className="text-xs text-neutral-500">Takipçi sayısı doğrulanmadı</div>
              </Card>
            ))}
          </div>
        );
      case "pool":
        return <div className="space-y-3">{demoPosts.map((p) => <PostCard key={p.id} id={p.id} />)}</div>;
      case "tr":
        return (
          <div className="space-y-3">
            <Card><p className="text-sm text-neutral-400">Çeviriler Claude API bağlanınca otomatik üretilecek. Aşağıdakiler demo örneklerdir.</p></Card>
            {demoPosts.map((p) => <PostCard key={p.id} id={p.id} />)}
          </div>
        );
      case "adapt":
        return (
          <Card>
            <label className="text-sm text-neutral-400">Uyarlanacak metin</label>
            <textarea value={text} onChange={(e) => setText(e.target.value)} rows={6}
              className="mt-1 w-full rounded-lg border border-neutral-700 bg-black p-3 text-white" placeholder="Metni buraya yapıştır..." />
            <button disabled className="mt-3 w-full rounded-xl bg-neutral-800 p-3 font-semibold text-neutral-500">RISEONIA tarzında yeniden yaz (Claude API bağlı değil)</button>
          </Card>
        );
      case "fav":
        return favs.length === 0 ? (
          <Card><p className="text-sm text-neutral-400">Henüz favori yok. İçerik havuzundan ekleyebilirsin. (Şimdilik sayfa yenilenince sıfırlanır; Supabase sonraki aşamada.)</p></Card>
        ) : (
          <div className="space-y-3">{favs.map((id) => <PostCard key={id} id={id} />)}</div>
        );
      case "settings":
        return (
          <div className="space-y-3">
            <Card>
              <div className="font-semibold">API anahtarları</div>
              <p className="mt-1 text-sm text-neutral-400">Anahtarlar kodda değil, Vercel &gt; Settings &gt; Environment Variables içinde tutulur.</p>
              {["NEXT_PUBLIC_SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_ANON_KEY", "ANTHROPIC_API_KEY", "BRAVE_SEARCH_API_KEY"].map((k) => (
                <div key={k} className="mt-2 break-all text-xs text-neutral-300">{k} — <span className="text-neutral-500">tanımlı değil</span></div>
              ))}
            </Card>
            <Card><p className="text-sm text-neutral-400">Instagram: otomatik giriş veya kazıma (scraping) yapılmayacak. Yalnızca herkese açık sayfalar ve resmi yöntemler kullanılacak.</p></Card>
          </div>
        );
    }
  };

  const current = TABS.find((t) => t.id === tab)!;
  return (
    <div className="mx-auto min-h-screen max-w-2xl pb-28">
      <header className="sticky top-0 z-10 border-b border-neutral-800 bg-black/95 p-4 backdrop-blur">
        <div className="text-xs font-bold tracking-[0.2em] text-neutral-400">RISEONIA</div>
        <h1 className="text-lg font-bold">{current.label}</h1>
      </header>
      <main className="p-4">{view()}</main>
      <nav className="fixed inset-x-0 bottom-0 border-t border-neutral-800 bg-black">
        <div className="mx-auto flex max-w-2xl overflow-x-auto">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex min-w-[72px] flex-1 flex-col items-center gap-0.5 px-2 py-2 text-[10px] ${tab === t.id ? "text-white" : "text-neutral-500"}`}>
              <span className="text-lg leading-none">{t.icon}</span>
              <span className="whitespace-nowrap">{t.label.split(" ")[0]}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
