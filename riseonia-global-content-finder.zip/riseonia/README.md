# RISEONIA GLOBAL CONTENT FINDER
Aşama 1: Arayüz (demo verili). Gerçek API entegrasyonu yok.

## Çalıştırma
```
npm install
npm run dev
```
Vercel'e GitHub reposunu bağlayarak yayınlayabilirsin (Framework: Next.js).
