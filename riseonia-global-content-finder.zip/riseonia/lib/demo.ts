// ⚠️ TÜMÜ DEMO VERİDİR. Gerçek Instagram hesabı/gönderisi değildir.
export type Account = { id: string; handle: string; country: string; lang: string; followers: number; topic: string };
export type Post = { id: string; accountId: string; original: string; lang: string; turkish: string };

export const demoAccounts: Account[] = [
  { id: "a1", handle: "@demo_disiplin", country: "ABD", lang: "İngilizce", followers: 182000, topic: "Disiplin" },
  { id: "a2", handle: "@demo_exito", country: "İspanya", lang: "İspanyolca", followers: 96500, topic: "Başarı" },
  { id: "a3", handle: "@demo_stoa", country: "Almanya", lang: "Almanca", followers: 61200, topic: "Felsefe" },
  { id: "a4", handle: "@demo_confianca", country: "Brezilya", lang: "Portekizce", followers: 54800, topic: "Özgüven" },
];

export const demoPosts: Post[] = [
  { id: "p1", accountId: "a1", lang: "İngilizce", original: "Discipline is choosing what you want most over what you want now.", turkish: "Disiplin, şu an istediğin şeyden çok, en çok istediğin şeyi seçmektir." },
  { id: "p2", accountId: "a2", lang: "İspanyolca", original: "El éxito se construye en silencio, día tras día.", turkish: "Başarı sessizlikte, gün be gün inşa edilir." },
  { id: "p3", accountId: "a3", lang: "Almanca", original: "Du kontrollierst nicht, was geschieht, nur wie du antwortest.", turkish: "Olanları kontrol edemezsin, yalnızca nasıl karşılık vereceğini." },
  { id: "p4", accountId: "a4", lang: "Portekizce", original: "A confiança nasce das promessas que você cumpre a si mesmo.", turkish: "Özgüven, kendine verdiğin sözleri tutmaktan doğar." },
];
